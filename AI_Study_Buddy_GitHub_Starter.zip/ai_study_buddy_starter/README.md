# AI Study Buddy

A beginner-friendly study assistant built with Python, Streamlit, and Google's Gemini API. It can explain a topic, create quiz questions, or summarize notes at a selected learning level.

## Features
- Explain concepts in simple language
- Generate five practice questions with an answer key
- Summarize pasted notes into bullet points
- Beginner, intermediate, and exam-revision modes
- Simple web interface

## Tech stack
- Python
- Streamlit
- Google Gemini API (`google-genai`)

## Run locally
1. Install Python 3.10 or newer.
2. Download or clone this repository.
3. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

4. Create a Gemini API key in Google AI Studio.
5. Set the key as an environment variable named `GEMINI_API_KEY`. Do not commit the key to GitHub.

   Windows PowerShell:
   ```powershell
   $env:GEMINI_API_KEY="your_key_here"
   ```

   macOS/Linux:
   ```bash
   export GEMINI_API_KEY="your_key_here"
   ```

6. Start the app:

   ```bash
   streamlit run app.py
   ```

## Streamlit Community Cloud
When deploying, add `GEMINI_API_KEY` under the app's Secrets settings. Never put the actual key in source code or a public repository.

## Limitations
- Requires internet access and a valid Gemini API key.
- AI-generated answers may be inaccurate and should be verified.
- This is a beginner portfolio project, not a production-ready educational system.

## Project status
Starter implementation. Run it and verify API access before describing it as tested or deployed.
